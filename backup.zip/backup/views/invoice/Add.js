import { cilAddressBook, cilUser, cilContact, cilCalendarCheck, cilDescription, cilNotes } from "@coreui/icons";
import CIcon from "@coreui/icons-react";
import { CForm, CInputGroup, CInputGroupText, CFormInput, CFormTextarea, CButton } from "@coreui/react";
import { MdDelete } from "react-icons/md";
import { FaEdit } from "react-icons/fa";
import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
//import { CiCalendarDate } from "react-icons/ci";

const Add = () => {
    const [list, setList] = useState([])
    const [total, setTotal] = useState(0)
    const [showForm, setShowForm] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const [itemsTxt, setItemsTxt] = useState([]);
    const [items, setItems] = useState([]);
    const id = sessionStorage.getItem('id');
    // const  setDescription ;
    // const setQuantity ;
    // const setPrice ;
    const description = useRef("");
    const qty = useRef("");
    const price = useRef("");
    // const handleClick = (e) => {
    //     e.preventDefault()
    //     if (!description || !qty || !price) {

    //         alert("Please fill in all inputs")
    //     }
    //     else {
    //         const newItems = {
    //             description,
    //             qty,
    //             price,
    //             //  amount,
    //         }
    //         // setDescription("")
    //         // setQuantity("")
    //         // setPrice("")
    //         // // setAmount("")
    //         setList([...list, newItems])
    //         // setIsEditing(false)
    //     }
    // }

    const handleItems = (e) => {
        setItemsTxt(e.target.value);
    }
    const handleClick = (e) => {
        setItems((prev) => {
            return [...prev, { description: itemsTxt, status: 0 }];
        });
        setItemsTxt("");
    }

        const [client_details, setClient_details] = useState({
            name: '',
            address: '',
            email: '',
            contact: '',
            // Add more fields as needed
          });
          const [item_details, setItem_details] = useState({
            description: '',
            qty: '',
            price: '',
            // Add more fields as needed
          })

          const handleChange = (e) => {
            const { name, value } = e.target;
           // console.log("Updating state:", name, value);
            setClient_details({
              ...client_details,
              [name]: value
            });
          };
        // const handleChange = (e) => {
        //     const { name, value } = e.target;
        //     console.log("Event:", name, value); // Log event properties
        //     setClient_details({
        //       ...client_details,
        //       [name]: value
        //     });
        //     console.log("Updated state:", client_details); // Log updated state
        //   };
        // const handleChange = (e) => {
        //     const { name, value } = e.target;
        //   // console.log("Event:", name, value); // Log event properties
        //     setClient_details(prevState => ({
        //      // const updatedState = { ...prevState, [name]: value };
        //       //console.log("Updated state:", updatedState); // Log updated state
        //       //return updatedState;
        //       ...prevState, 
        //       [name]: value 
        //     }));
        //   };
        //  console.log("Current state:", client_details); // Log current state
    // const [client_details, setClient_details] = useState({
    //     name: '',
    //     address: '',
    //     email: '',
    //     contact: '',
    // });

    // const handleChange = (e) => {
    //     const { name, value } = e.target;
    //     setClient_details({
    //         ...client_details,
    //         [name]: value
    //     });
    // };

    // // // Log the updated state whenever client_details changes
    //  useEffect(() => {
    // console.log("Updated state:", client_details);
    // }, [client_details]);


    // const sendData = async () => {
    //     try {
    //         await axios.post('http://localhost:8081/api/invoices/addInvoice', { data: client_details });
    //         console.log('Data sent successfully');
    //     } catch (error) {
    //         console.error('Error sending data:', error);
    //     }
    // };
    // const sendData = async () => {
    //     try {
    //         const clientDetailsJSON = JSON.stringify(client_details);
    //         await axios.post('http://localhost:8081/api/invoices/addInvoice', { data: clientDetailsJSON });
    //         console.log('Data sent successfully');
    //     } catch (error) {
    //         console.error('Error sending data:', error);
    //     }
    // };
    
    const sendData = async () => {
        try {
            // const clientDetailsJSON = JSON.stringify(client_details);
            // await axios.post('http://localhost:8081/api/invoices/addInvoice', { data: clientDetailsJSON }, {
            //     headers: {
            //         'Content-Type': 'application/json',
            //         body: JSON.stringify(client_details),
            //     }
            const response = await axios.post('http://localhost:8081/api/invoices/addInvoice', {
                id,
                client_details: client_details, item_details: item_details
            })
            console.log('Data sent successfully');
        } catch (error) {
            console.error('Error sending data:', error);
        }
    };
    

    // const sendData = async () => {
    //   try {
    //     await axios.post('http://localhost:8081/api/invoices/addInvoice', { client_details: client_details });
    //     console.log('Data sent successfully');
    //   } catch (error) {
    //     console.error('Error sending client_details:', error);
    //   }
    // };

    return (
        <>
            <CForm>
                {/* <CInputGroup className="mb-3 mt-3 ">
                    <CInputGroupText>
                        <CIcon icon={cilUser} />
                    </CInputGroupText>
                    <CFormInput type="text" placeholder="Company Name" aria-label="Disabled input example"  readOnly />

                    <CInputGroupText >
                        <CIcon icon={cilAddressBook} />
                    </CInputGroupText>
                    <CFormInput type="text" placeholder="Address"  />
                </CInputGroup>
                <CInputGroup className='mb-4'>
                    <CInputGroupText id='basic-addon1'>@</CInputGroupText>
                    <CFormInput type='email' placeholder='Email'  />

                    <CInputGroupText>
                        <CIcon icon={cilContact} />
                    </CInputGroupText>
                    <CFormInput type='number' id='floatingInput' floatingLabel='Contact' placeholder='Contact' />
                </CInputGroup> */}


                <CInputGroup className="mb-3 mt-3 ">
                    <CInputGroupText>
                        <CIcon icon={cilUser} />
                    </CInputGroupText>
                    <CFormInput type="text" placeholder="Client Name" name="name" value={client_details.name} onChange={handleChange} />

                    <CInputGroupText >
                        <CIcon icon={cilAddressBook} />
                    </CInputGroupText>
                    <CFormInput type="text" placeholder="Address" name="address"
                        value={client_details.address} onChange={handleChange}
                    />
                </CInputGroup>
                <CInputGroup className='mb-4'>
                    <CInputGroupText id='basic-addon1'>@</CInputGroupText>
                    <CFormInput type='email' placeholder='Email' name="email"
                        value={client_details.email} onChange={handleChange}
                    />

                    <CInputGroupText>
                        <CIcon icon={cilContact} />
                    </CInputGroupText>
                    <CFormInput type='number' id='floatingInput' floatingLabel='Contact' placeholder='Contact' name="contact"
                        value={client_details.contact} onChange={handleChange}
                    />
                    {/* <CInputGroupText>
                        <CIcon icon={cilCalendarCheck} />
                    </CInputGroupText> */}
                    {/* <CFormInput type="date" placeholder="Invoice date" name="contact" */}
                    {/* value={client_details} onChange={(e) => setClient_details(e.target.value)} */}
                    {/* /> */}
                </CInputGroup>

                <CInputGroup className="mb-3 mt-3">
                    <CInputGroupText>
                        <CIcon icon={cilDescription} />
                    </CInputGroupText>
                    <CFormInput type="text" id='floatingInput' floatingLabel="Description" floatingClassName="mb-8" placeholder="name" value={itemsTxt} onChange={handleItems} />
                </CInputGroup>

                <CInputGroup className="mb-3 mt-3">
                    <CFormInput type="number" placeholder="Quantity" />
                    <CInputGroupText>$</CInputGroupText>
                    <CFormInput aria-label="Amount (to the nearest dollar)" type="number" placeholder="Price" />
                    <CInputGroupText>.00</CInputGroupText>
                </CInputGroup>
                <CInputGroup>
                    <CButton onClick={handleClick}
                        type="submit"
                        className="mb-5 bg-blue-500 text-white font-bold py-2 px-8 rounded shadow border-2 border-bule-500 hover:bg-transparent hover:text-blue-500 transition-all duration-300">
                        {/* {isEditing ? "Edit Items" : "Add Items"} */}Add Items
                    </CButton>
                </CInputGroup>
                <CInputGroup>
                    <table width="100%" className="mb-10">
                        <thead>
                            <tr className="bg-gray-100 p-1">
                                <td className="font-bold">Description</td>
                                <td className="font-bold">Quantity</td>
                                <td className="font-bold">Price</td>
                                {/* <td className="font-bold">Amount</td> */}
                            </tr>
                        </thead>

                        {items.map(({ e, i }) => (
                            <React.Fragment key={i}>
                                {/* {e.description} */}
                                <tbody>
                                    <tr>
                                        <td>{e.description}</td>
                                        <td>{e.qty}</td>
                                        <td>{e.price}</td>
                                        {/* <td className="amount">{amount}</td> */}
                                        <td><CButton><MdDelete className="text-red-500 font-bold text-xl" />
                                        </CButton></td>
                                        <td><CButton><FaEdit className="text-green-500 font-bold text-xl" />
                                        </CButton></td>
                                    </tr>
                                </tbody>

                            </React.Fragment>
                        ))}
                    </table>
                    {/* <div>
                <h2 className="flex items-end justify-end text-gray-800 text-4xl font-bold">Rs. {total}</h2>
            </div> */}
                </CInputGroup>
                <CInputGroup className='mb-4'>
                    <CInputGroupText>
                        <CIcon icon={cilNotes} />
                    </CInputGroupText>
                    <CFormTextarea id='floatingTextarea' floatingLabel='Add Notes for Clients' placeholder='Add Notes for Clients'></CFormTextarea>
                </CInputGroup>
                <CButton className="mb-3 mt-2" as="a" color="primary"
                    // href="/Showinvoice" role="button"
                    onClick={sendData}>
                    Create Invoice</CButton>
            </CForm>
        </>
    )
}
export default Add